vim.opt.runtimepath:append(',~/.config/nvim')
vim.api.nvim_command('set runtimepath^=~/.vim')
vim.api.nvim_command('let &packpath = &runtimepath')
vim.api.nvim_command("let g:vimspector_base_dir='/home/cremoso/.local/share/nvim/site/pack/packer/start/vimspector'")

require("bat")
require("settings")
require("plugins")
vim.cmd([[ set guicursor= ]])
