-- This file can be loaded by calling `lua require('plugins')` from your init.vim

-- Only required if you have packer configured as `opt`
vim.cmd [[packadd packer.nvim]]

return require('packer').startup(function(use)
  -- Packer can manage itself
  use 'wbthomason/packer.nvim'

  use 'rstacruz/vim-closer'
  use {'tpope/vim-dispatch', opt = true, cmd = {'Dispatch', 'Make', 'Focus', 'Start'}}
  use 'kshenoy/vim-signature'

  --"Debug
  use 'nvie/vim-flake8'
  use {
    'puremourning/vimspector',
    run = "let g:vimspector_enable_mappings = 'HUMAN'"
  }

  ------------------------------
  --html
  use 'alvan/vim-closetag'
  use 'mattn/emmet-vim'
  use 'rstacruz/sparkup'
  ----------------------------
  
  --Bidings/git
  use 'rbong/vim-flog'
  use 'tpope/vim-unimpaired'
  use 'tpope/vim-fugitive'
  --use 'airblade/vim-gitgutter'
  --""""""""""""""""""""""""""""
  
  --Python
  use 'heavenshell/vim-pydocstring'
  --"use 'davidhalter/jedi-vim'
  --let g:pydocstring_doq_path = '/home/shadow/envs_py/env/ENV/bin/doq'
  use 'jmcantrell/vim-virtualenv'
  --"""""""''''''''''''''''"""""""
  
  --"Arduino
  use 'sudar/vim-arduino-syntax'
  use 'stevearc/vim-arduino'
  --""""""""""""""""""""""""""""""
  --"Nvim lsp's
  use 'williamboman/nvim-lsp-installer'
  use 'neovim/nvim-lspconfig'
  use 'hrsh7th/nvim-cmp' 
  --use 'mfussenegger/nvim-jdtls' 
  --use 'neoclide/coc.nvim'
  use 'hrsh7th/cmp-nvim-lsp'
  use 'hrsh7th/cmp-buffer'
  use 'hrsh7th/cmp-path'
  use 'hrsh7th/cmp-cmdline'
  use 'dcampos/cmp-snippy'
  use 'dcampos/nvim-snippy'
  use 'preservim/tagbar'
  
  --""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
  --"Autocomplete
  use 'valloric/youcompleteme'
  --"use 'github/copilot.vim'
  --""""""""""""""""""""""""""""
  
  --"Docstring
  use {
    'kkoomen/vim-doge',
    run = ':call doge#install()'
  }
  --""""""""""""""""""""""""""
  
  --"Better writing
  use 'vim-scripts/java_fold'
  use 'jiangmiao/auto-pairs'
  use 'frazrepo/vim-rainbow'
  use 'mbbill/undotree'
  use 'chrisbra/csv.vim'
  --""""""""""""""""""""""""""""
  
  --"Formating/linting
  use 'neomake/neomake'
  vim.api.nvim_command("let g:neomake_python_enabled_makers = ['pylint']")
  use 'sbdchd/neoformat'
  --""""""""""""""""""""""""""""""""""""
  
  --"UI
  use "nvim-lua/plenary.nvim"
  use 'vim-airline/vim-airline'
  use 'vim-airline/vim-airline-themes'
  vim.api.nvim_command("let g:airline#extensions#tabline#enabled = 1")
  vim.api.nvim_command("let g:airline#extensions#tabline#formatter = 'default'")

  use 'Mr-76/bat_vim'
  use 'lambdalisue/battery.vim'
  vim.api.nvim_command("let g:airline#extensions#battery#enabled = 1")
  -------------------------- 
  
  --"Maven
  use 'mikelue/vim-maven-plugin'
   --""""""""""""""""""""""""""""""""""
  --"Navigation
  use 'scrooloose/nerdtree'
--""""""""""""""""""""""""""""""""""
 --Test
  use 'vim-test/vim-test'
end)
