print("HAPPY EDITING")
vim.api.nvim_command('source ~/.vimrc')
